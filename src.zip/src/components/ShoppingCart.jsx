import React, { useState, useRef } from 'react';
import Slider from 'react-slick';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import { FaArrowLeft, FaArrowRight, FaShoppingCart } from 'react-icons/fa';
import ShoppingCartCard from '../layouts/ShoppingCartCard';

const ShoppingCart = () => {
    const [cartItems, setCartItems] = useState([]);
    const data = [
        {
            id: 1,
            img: "/src/assets/img/cart.jpeg",
            name: 'Paracetamol',
            price: '20',
            chemist: 'Rubik Medical',

        },
        {
            id: 2,
            img: "/src/assets/img/cart2.jpeg",
            name: 'Glucose',
            price: '30' ,
            chemist: 'Atharv Medical',
        },
        {
            id: 3,
            img: "/src/assets/img/cart3.jpeg",
            name: 'Aspirin ',
            price: '5',
            chemist: 'Heatline Medical',
        },
        {
          id: 4,
          img: "/src/assets/img/cart4.jpeg",
          name: 'Ciprofloxacin',
          price: '12',
          chemist: 'Vishwa Medical',
      },
      {
        id: 5,
        img: "/src/assets/img/cart5.jpeg",
        name: 'Warfarin',
        price: '13',
        chemist: 'Atharv Medical',
    },
    {
      id: 6,
      img: "/src/assets/img/cart6.jpeg",
      name: 'Insulin',
      price: '56',
      chemist: 'MedLife Medical',
  },
  {
    id: 7,
    img: "/src/assets/img/cart7.jpeg",
    name: 'Morphine',
    price: '99',
    chemist: 'Wellness Medical',
  },
  {
    id: 8,
    img: "/src/assets/img/cart8.jpeg",
    name: 'Ciprofloxacin',
    price: '90',
    chemist: 'Atharv Medical',
  },
  {
    id: 9,
    img: "/src/assets/img/cart9.jpeg",
    name: 'Aspirin',
    price: '90',
    chemist: 'Rubik Medical',
  },
  {
    id: 10,
    img: "/src/assets/img/cart10.jpeg",
    name: 'Morphine',
    price: '9',
    chemist: 'Medlife Medical',
  },
  {
    id: 11,
    img: "/src/assets/img/cart11.jpeg",
    name: 'Warfarin',
    price: '112',
    chemist: 'Vishwa Medical',
  },{
    id: 12,
    img: "/src/assets/img/cart12.jpeg",
    name: 'Paracetamol',
    price: '88',
    chemist: 'Atharv Medical',
  },
  {
    id: 13,
    img: "/src/assets/img/cart13.jpeg",
    name: 'Metformin',
    price: '21',
    chemist: ' Heartline Medical',
  },
        // Add more product data as needed
    ];

    const slider = useRef(null);

    const settings = {
        accessibility: true,
        dots: true,
        infinite: true,
        speed: 500,
        arrows: false,
        slidesToShow: data.length > 3 ? 3 : data.length,
        slidesToScroll: 1,
        responsive: [
            {
                breakpoint: 1023,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 3,
                    infinite: true,
                    dots: true,
                },
            },
            {
                breakpoint: 768,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 2,
                    initialSlide: 2,
                },
            },
            {
                breakpoint: 480,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1,
                    initialSlide: 2,
                },
            },
        ],
    };

    const addToCart = (item) => {
        setCartItems([...cartItems, item]);
    };

    const removeFromCart = (itemId) => {
        const updatedCartItems = cartItems.filter((item) => item.id !== itemId);
        setCartItems(updatedCartItems);
    };

    return (
        <div className="min-h-screen flex flex-col justify-center lg:px-32 px-5 pt-16">
            <div className="flex flex-col items-center lg:flex-row justify-between mb-10 lg:mb-0">
                <div>
                    <h1 className="text-4xl font-semibold text-center lg:text-start">Shopping Cart</h1>
                    <p className="mt-2 text-center lg:text-start">Your shopping cart items</p>
                </div>
                <div className="flex gap-5 mt-4 lg:mt-0">
                    <button className="bg-[#d5f2ec] text-backgroundColor px-4 py-2 rounded-lg active:bg-[#ade9dc]" onClick={() => slider.current.slickPrev()}>
                        <FaArrowLeft size={25} />
                    </button>
                    <button className="bg-[#d5f2ec] text-backgroundColor px-4 py-2 rounded-lg active:bg-[#ade9dc]" onClick={() => slider.current.slickNext()}>
                        <FaArrowRight size={25} />
                    </button>
                </div>
                <div className="flex items-center">
                    <FaShoppingCart size={30} className="text-gray-700" />
                    <span className="ml-1 text-gray-700">{cartItems.length}</span>
                </div>
            </div>
            <div className="mt-5">
                <Slider ref={slider} {...settings}>
                    {data.map((item, index) => (
                        <div key={index} className="text-black rounded-xl shadow-[rgba(0,_0,_0,_0.24)_0px_3px_8px] mb-2 cursor-pointer" style={{ width: '150px' }}>
                            <div>
                                <img src={item.img} alt="Product" className="h-[190px] w-full object-cover rounded-t-xl" />
                            </div>
                            <div className="flex flex-col justify-center items-center p-4">
                                <h1 className="font-semibold text-lg">{item.name}</h1>
                                <h3 className="mt-2">${item.price}</h3>
                                <button className="bg-green-500 text-white px-3 py-1 rounded-md mt-4" onClick={() => addToCart(item)}>
                                    Add to Cart
                                </button>
                            </div>
                        </div>
                    ))}
                </Slider>
            </div>
            <div className="mt-5">
                <ul>
                    {cartItems.map((item, index) => (
                        <ShoppingCartCard key={index} item={item} image={item.img} removeFromCart={() => removeFromCart(item.id)} />
                    ))}
                </ul>
            </div>
        </div>
    );
};

export default ShoppingCart;
